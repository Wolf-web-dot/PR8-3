module org.example.demo6 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires com.zaxxer.hikari;


    opens org.example.demo6 to javafx.fxml;
    exports org.example.demo6;
}