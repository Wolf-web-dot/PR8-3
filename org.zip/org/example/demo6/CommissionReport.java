package org.example.demo6;

public class CommissionReport {
    private final String fullName;
    private final double salary;
    private final double percent;
    private final double commission;
    private final double total;

    public CommissionReport(String fullName, double salary, double percent, double commission, double total) {
        this.fullName = fullName;
        this.salary = salary;
        this.percent = percent;
        this.commission = commission;
        this.total = total;
    }

    public String getFullName() {
        return fullName;
    }

    public double getSalary() {
        return salary;
    }

    public double getPercent() {
        return percent;
    }

    public double getCommission() {
        return commission;
    }

    public double getTotal() {
        return total;
    }
}
